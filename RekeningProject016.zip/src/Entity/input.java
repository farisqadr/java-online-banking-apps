/* Nama Program     : Aplikasi Sistem Informasi & Manajemen Rekening Bank
 * Nama             : Faris Abdurrahman
 * NPM              : 140203120016
 */

package Entity;

import GUI.Transfer;
import GUI.DataTransaksi;
import Entity.koneksi;
import javax.swing.JOptionPane;

public class input {
private String idrekening;
private String rekening;
private String tujuan;
private String jumlah;
private String ket;
private String tanggal;
private String hapus;

    public String getIdekening(){
        return idrekening;
    }
    public void setIdrekening(String idrekening){
        this.idrekening = idrekening;
    }
    public String getRekening(){
        return rekening;
    }
    public void setRekening(String rekening){
        this.rekening = rekening;
    }
    public String getTujuan(){
        return tujuan;
    }
    public void setTujuan(String tujuan){
        this.tujuan = tujuan;
    }
    public String getJumlah(){
        return jumlah;
    }
    public void setJumlah(String jumlah){
        this.jumlah = jumlah;
    }
    public String getKet(){
        return ket;
    }
    public void setKet(String ket){
        this.ket = ket;
    }
    public String getTanggal(){
        return tanggal;
    }
    public void setTanggal(String tanggal){
        this.tanggal = tanggal;
    }
    
   
    public void insertdata(){
    koneksi kon = new koneksi();
    String i = "insert into t_transfer values('" + this.idrekening + "','" + this.rekening + "','" + this.tujuan + "','" + this.jumlah + "','" + this.ket + "','" + this.tanggal + "')";
    kon.Query(i);  
    }
    public void hapusdata(){
    koneksi kon = new koneksi();
    String i = "delete from t_transfer where id_transfer = '"+this.idrekening+"'";
    kon.Query(i);  
    }
    public void search(){
    koneksi kon = new koneksi();
    String i = "select t_transfer.id_transfer,t_nasabah.nama,t_transfer.norek,t_transfer.notuj,t_transfer.jumlah,t_transfer.keterangan,t_transfer.tanggal from t_transfer inner join t_nasabah on t_nasabah.norek = t_transfer.norek where t_transfer.id_transfer= '"+this.idrekening+"'";
    kon.Query(i);  
       
    }
    

}
