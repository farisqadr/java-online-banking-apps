/* Nama Program     : Aplikasi Sistem Informasi & Manajemen Rekening Bank
 * Nama             : Faris Abdurrahman
 * NPM              : 140203120016
 */
package Entity;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import javax.swing.JOptionPane;


public class koneksi {
    private String user = "root";
    private String pass = "";
    private Statement stmt = null;
    private Connection con = null;
    private ResultSet rs = null;
    
    public koneksi(){
        try {
            Class.forName("org.gjt.mm.mysql.Driver");
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(null, ""+e.getMessage(), "JDBC Driver Error", JOptionPane.WARNING_MESSAGE);          
        }
        try {
            con = (Connection)
            DriverManager.getConnection("jdbc:mysql://localhost/db_rekening016",user,pass);
            stmt = (Statement) con.createStatement();
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(null, ""+e.getMessage(), "Connection Error", JOptionPane.WARNING_MESSAGE);          
        }
    }
   public ResultSet getData(String SQLString){
       try {
           rs = stmt.executeQuery(SQLString);
       }
       catch (Exception e){
            JOptionPane.showMessageDialog(null, ""+e.getMessage(), "Communication Error", JOptionPane.WARNING_MESSAGE);          
        }
       return rs;
   } 
   public void Query(String SQLString){
       try {
           stmt.executeUpdate(SQLString);
       }
       catch (Exception e){
            JOptionPane.showMessageDialog(null, ""+e.getMessage(), "Communicaton Error", JOptionPane.WARNING_MESSAGE);          
        }
   }
}

