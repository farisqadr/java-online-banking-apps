/* Nama Program     : Aplikasi Sistem Informasi & Manajemen Rekening Bank
 * Nama             : Faris Abdurrahman
 * NPM              : 140203120016
 */

package Entity;
import GUI.DataNasabah;
import GUI.Transfer;

public class nasabah {

    private String norek;
    private String nama;
    private double saldoawal;
    private double sisasaldo;
    private String pin;
    private double jumlahtransfer;


    public double getJumlahtransfer() {
        return jumlahtransfer;
    }

    public void setJumlahtransfer(double jumlahtransfer) {
        this.jumlahtransfer = jumlahtransfer;
    }

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }
    public String getNorek(){
        return norek;
    }
    public void setNorek(String norek){
        this.norek = norek;
    }
    public String getNama(){
        return nama;
    }
    public void setNama(String nama){
        this.nama = nama;
    }
    public double getSaldoawal(){
        return saldoawal;
    }
    public void setSaldoawal(double saldoawal){
        this.saldoawal = saldoawal;
    }
    public double getSisasaldo(){
        return sisasaldo;
    }
    public void setSisasaldo(double sisasaldo){
        this.sisasaldo = sisasaldo;
    }
    
    public void insertdata(){
        koneksi kon = new koneksi();
        String i = "insert into t_nasabah values('" + this.norek + "','" + this.nama + "','" + this.pin + "','" + this.saldoawal + "')";
        kon.Query(i);
    }
    
    public void hitung(){
        this.sisasaldo=this.saldoawal-this.jumlahtransfer;
    }
    
    public String updateData(){
        koneksi kon = new koneksi();
        String i = "update t_nasabah set nama = '"+this.nama+"', pin='"+this.pin+"', saldo='"+this.sisasaldo+"' where norek = '"+this.norek+"'";
        kon.Query(i);
        return i;
    }
    public void updateSaldo(){        
        koneksi kon = new koneksi();
        String i = "update t_nasabah set saldo = '"+this.sisasaldo+"' where norek = '"+this.norek+"'";
        kon.Query(i);
    }
    public String hapusRekening(){
        koneksi kon = new koneksi();
        String i = "delete from t_nasabah where norek = '"+this.norek+"'";
        kon.Query(i);
        return i;
    }
    
    /*public String rekening(){
        koneksi kon = new koneksi();
        String i = "select * t_nasabah where norek = '"+this.norek+"'";
        kon.Query(i);
        return i;
    }*/
}
