
package Main;

import GUI.Login;

public class Main {

    public static void main(String[] args) {
        SplashScreen start = new SplashScreen();
        Login log = new Login();
        log.setVisible(true);
        log.setLocationRelativeTo(null);
    }
    
}
