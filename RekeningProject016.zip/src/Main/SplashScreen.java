/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.awt.Component;
import java.awt.Font;
import javax.swing.*;
import javax.swing.border.Border;


    public class SplashScreen extends JFrame {

    int a = 0;
    JProgressBar progressBar = new JProgressBar(0, 100);
    JLabel label = new JLabel();
    Border border = BorderFactory.createTitledBorder("Reading…");

    SplashScreen() {
        setTitle("Assalamu'alaikum");
        this.setIconImage(new ImageIcon(getClass().getResource("/Image/Heart.png")).getImage());                
        progressBar.setStringPainted(true);
        progressBar.setBorder(border);
        label.setText("WELCOME TEH BELINDA");
        label.setFont(new Font("Tahoma", 1, 21));
        setLayout(null);
        add(label);
        label.setBounds(10, 10, 400, 100);
        Component add = add(progressBar);
        progressBar.setBounds(10, 130, 270, 40);
        pack();
        setSize(300, 210);
        setVisible(true);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(3);
        while (a <= 100) {
            progressBar.setValue(a);
            try {
                Thread.sleep(20);
            } catch (InterruptedException e) {
            }
            a += 1;
        }
        dispose();
    }
    public static void main(){
    try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            new SplashScreen();
        } catch (Exception ex) {
        }
    }
}

